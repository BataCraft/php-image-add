<?php
session_start();
// Register is the name used in form.
if(isset($_POST['register'])) {
    //captruing the data
    $username=$_POST['username'];
    $password =($_POST['password']);
    $mpass=md5($password);
    $email= $_POST['email'];
  
    $status=1;
    $role='user';

      //making connection6
      
      include("connection.php");

    //Preparing the SQL Statement for Making register
    $sql = "INSERT INTO user (username, password, email, status, role) VALUES ('$username', '$mpass', '$email', '$status', '$role')";

    $qry = mysqli_query($conn, $sql);         // die(mysqli_error($conn)

    if($qry) {
        header("location: login.php");
        echo "Hey buddy, your data has been registered.\n";
    } else {
        echo "Oops! Something went wrong:\n " . mysqli_error($conn);
    }
  
    //execiting the query
  

}
?>


<!-- html code to make form -->
<!DOCTYPE html>
<!-- making a registration page that will sending new data to database -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register page</title>
</head>
<body>
    <style>
        form{
            text-align:center;
        }
    
    </style>
<form method="POST" action="" enctype="multipart/form-data" name="Register" style="margin: center;">
        <fieldset>
            <br>
            <br>
            <legend>User Register</legend>
            <input type="text" name="username" placeholder="Enter your Username" required> 
            <br>
            <br>
            <input type="password" name="password" placeholder="Create a new password" required>
            <br>
            <br>
            <input type="password" name="password" placeholder="Confirm your new password" required>
            <br>
            <br>
            <input type ="email" name="email" placeholder="Enter your email" required>
            <br>
            <br>
            <input type="submit" name="register" value="Register">
            <br>
            <p>Already have an account ? <a href="login.php">Log in</a></p>

        </fieldset>
    </form>

</body>
</html>