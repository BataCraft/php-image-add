<?php

echo "WELCOME, " .$_SESSION['username']. "<br>";
echo "<a href=logout.php>Logout</a>";

echo "<hr>";
echo "<a href='dashboard.php'>Home</a> | ";
echo "<a href='displayuser.php'>Users</a> | ";
echo "<a href='inquiry.php'>Inquiry</a> | ";
echo "<a href='category.php'>Category</a> | ";
echo "<hr>";
?>