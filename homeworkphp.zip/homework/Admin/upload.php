<!DOCTYPE html>
<hml>
<body>

<form action="" method="post" enctype="multipart/form-data">
        <!-- Select image to imgupload: -->
    <input type="file" name="imgupload" id="fileToImgupload">
    <input type="submit" value="upload" name="submit">
</form>

</body>
</hml>

<?php
if(isset($_POST['submit']))
{
$uimage = $_FILES["imgupload"] ["name"];
$usize = $_FILES["imgupload"] ["size"];
$utype = $_FILES["imgupload"] ["type"];
$utmp = $_FILES["imgupload"] ["tmp_name"];

$dest ="../upload/" . $uimage;
if(move_uploaded_file($utmp, $dest))
{
    echo"uploded";
}
else 
{
    echo "*************unable To upload**********";
}
}
?>